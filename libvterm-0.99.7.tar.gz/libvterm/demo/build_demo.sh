#!/bin/sh
PKG_CFG=`pkg-config --cflags --libs glib-2.0 ncurses`

rm -rf vshell
gcc -o vshell -lvterm $PKG_CFG *.c -ggdb3

